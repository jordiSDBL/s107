package n1ex2;

public class Gos extends Animal {

	@Override
	@Deprecated // el marquem com a deprecated
	public void sonar() {
		System.out.println("Borda");
	}
}
