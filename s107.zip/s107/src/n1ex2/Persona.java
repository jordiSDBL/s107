package n1ex2;

public class Persona {
	String nom;
	int edat;
	char genere;

	public Persona(String nom, int edat, char genere) {
		this.nom = nom;
		this.edat = edat;
		this.genere = genere;
	}

	@Override
	@Deprecated // el marquem com a deprecated
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("Persona [nom=");
		builder.append(nom);
		builder.append(", edat=");
		builder.append(edat);
		builder.append(", genere=");
		builder.append(genere);
		builder.append("]");
		return builder.toString();
	}
}
