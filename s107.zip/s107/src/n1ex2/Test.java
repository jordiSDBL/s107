package n1ex2;

public class Test {
	/**
	 * esborrem l'av�s del compilador conforme s'est� fent servir un m�tode
	 * deprecated
	 */
	@SuppressWarnings("deprecation")
	public static void main(String[] args) {
		// creem objecte animal i cridem m�tode sonar()
		Animal animal = new Animal();
		animal.sonar();

		// fem el mateix amb gos, classe filla, i comprovem que el m�tode se sobreescriu
		Gos gos = new Gos();
		gos.sonar(); // ens marca que �s un m�tode deprecated

		/**
		 * creem un objecte persona i veiem que el m�tode toString se sobreescriu de la
		 * classe pare Object, ja no mostra la refer�ncia en mem�ria de l'objecte, sino
		 * el que s'ha especificat dins de la classe Persona
		 */
		Persona persona = new Persona("Bel", 28, 'H');
		System.out.println(persona.toString());// ens marca que �s un m�tode deprecated
	}
}
