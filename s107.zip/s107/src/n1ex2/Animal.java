package n1ex2;

public class Animal {

	public void sonar() {
		System.out.println("Emet un so.");
	}
}
