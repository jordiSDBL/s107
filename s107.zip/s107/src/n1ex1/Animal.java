package n1ex1;

public class Animal {

	public void sonar() {
		System.out.println("Emet un so.");
	}
}
