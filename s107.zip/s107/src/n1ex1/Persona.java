package n1ex1;

public class Persona {
	String nom;
	int edat;
	char genere;

	public Persona(String nom, int edat, char genere) {
		this.nom = nom;
		this.edat = edat;
		this.genere = genere;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("Persona [nom=");
		builder.append(nom);
		builder.append(", edat=");
		builder.append(edat);
		builder.append(", genere=");
		builder.append(genere);
		builder.append("]");
		return builder.toString();
	}
}
