package n1ex1;

public class Gos extends Animal {

	@Override
	public void sonar() {
		System.out.println("Borda");
	}
}
